package com.app.model;

import java.util.Date;

public class Hospital {

    private int id;
    private String name;
    private Address address;
    private String phone;
    private int beds;
    private int doctors;
    private int ventilators;
    private Date lastUpdate;

    public Hospital() {
        super();
    }

    public Hospital(int id, String name, Address address, String phone, int beds, int doctors, int ventilators,
            Date lastUpdate) {
        this.setId(id);
        this.setName(name);
        this.setAddress(address);
        this.setPhone(phone);
        this.setBeds(beds);
        this.setDoctors(doctors);
        this.setVentilators(ventilators);
        this.setLastUpdate(lastUpdate);
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public int getVentilators() {
        return ventilators;
    }

    public void setVentilators(int ventilators) {
        this.ventilators = ventilators;
    }

    public int getDoctors() {
        return doctors;
    }

    public void setDoctors(int doctors) {
        this.doctors = doctors;
    }

    public int getBeds() {
        return beds;
    }

    public void setBeds(int beds) {
        this.beds = beds;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Id : " + this.getId() + " , Name : " + this.getName();
    }

    // if id same then both object same and if name and pin same then consider it as
    // equal
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (super.getClass() != obj.getClass())
            return false;
        Hospital hospital = (Hospital) obj;
        boolean isIdSame = hospital.getId() == this.getId();
        boolean isNameSame = hospital.getName().equals(this.getName());
        boolean isPinSame = hospital.getAddress().getPinCode() == this.getAddress().getPinCode();
        return isIdSame || (isNameSame && isPinSame);
    }
}
