package com.app.model;

public class User {

    private int userId;
    private String userName;
    private String password;
    private String phone;
    private Address address;
    private String type;
    private int status;

    public User(String userName, String password, String type) {
        this.userName = userName;
        this.password = password;
        this.type = type;
    }

    public User() {
        super();
    }

    public User(int userId, String userName, String password, String type, Address address, String phone, int status) {
        this.userId = userId;
        this.userName = userName;
        this.password = password;
        this.type = type;
        this.setAddress(address);
        this.phone = phone;
        this.status = status;
    }

    public int getUserId() {
        return userId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    // public Address getArea() {
    //     return address;
    // }

    // public void setArea(Address address) {
    //     this.address = address;
    // }
    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "id : " + userId + " , userName : " + userName + " , type : " + type;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (super.getClass() != obj.getClass())
            return false;
        User user = (User) obj;
        return user.getUserName().equals(this.getUserName()) && user.getUserId() == this.getUserId();
    }

}
