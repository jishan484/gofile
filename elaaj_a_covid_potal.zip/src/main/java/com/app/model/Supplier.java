package com.app.model;

public class Supplier {
    private int id;
    private String name;
    private String phone;
    private Address address;
    private int pinCode;
    private int avalablity;

    public Supplier() {
        super();
    }

    public Supplier(String name, int pinCode) {
        this.name = name;
        this.pinCode = pinCode;
    }

    public Supplier(int id, String name, String phone, Address address, int pinCode, int avalablity) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.address = address;
        this.pinCode = pinCode;
        this.avalablity = avalablity;
    }

    public int getAvalablity() {
        return avalablity;
    }

    public void setAvalablity(int avalablity) {
        this.avalablity = avalablity;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPinCode() {
        return pinCode;
    }

    public void setPinCode(int pinCode) {
        this.pinCode = pinCode;
    }

    @Override
    public String toString() {
        return "id : " + this.getId() + " , name : " + this.getName() + " , address : " + this.getAddress()
                + " , avaliablity : " + this.getAvalablity();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (super.getClass() != obj.getClass())
            return false;
        Supplier supplier = (Supplier) obj;
        boolean isIdSame = supplier.getId() == this.getId();
        boolean isNameSame = supplier.getName().equals(this.getName());
        boolean isAddressSame = supplier.getAddress().equals(this.getAddress());
        return isIdSame || (isNameSame && isAddressSame);
    }
}
