package com.app.model;

public class Address {
    private int pinCode;
    private String street;
    private String city;
    private String state;

    public Address() {
        super();
    }

    public Address(int pinCode, String street, String city, String state) {
        this.pinCode = pinCode;
        this.street = street;
        this.city = city;
        this.state = state;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public int getPinCode() {
        return pinCode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setPinCode(int pinCode) {
        this.pinCode = pinCode;
    }

    @Override
    public String toString() {
        return street + " " + city + " " + state + " " + pinCode;
    }

    // equal
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (super.getClass() != obj.getClass())
            return false;
        Address area = (Address) obj;
        boolean isStreetSame = area.getStreet().equals(this.getStreet());
        boolean isCitySame = area.getCity().equals(this.getCity());
        boolean isPinSame = area.getPinCode() == this.getPinCode();
        boolean isSateSame = area.getState().equals(this.getState());
        return (isCitySame && isStreetSame && isSateSame && isPinSame);
    }
}
