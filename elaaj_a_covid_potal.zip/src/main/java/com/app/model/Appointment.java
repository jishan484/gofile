package com.app.model;

import java.util.Date;

public class Appointment {
    private int id;
    private User user;
    private Hospital hospital;
    private String cause; // cause can be COVID test or vaccination
    private Date appointmentTime;
    private String status;

    public Appointment() {
        super();
    }

    public Appointment(User user, Hospital hospital, String cause) {
        this.user = user;
        this.hospital = hospital;
        this.cause = cause;
    }

    public Appointment(int id, User user, Hospital hospital, String cause, Date appointmentTime, String status) {
        this.id = id;
        this.user = user;
        this.hospital = hospital;
        this.cause = cause;
        this.appointmentTime = appointmentTime;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public Date getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(Date appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public Hospital getHospital() {
        return hospital;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return user.getUserName() + " appointed to " + hospital.getName() + " time : " + appointmentTime;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (super.getClass() != obj.getClass())
            return false;
        Appointment appointment = (Appointment) obj;
        return appointment.getUser().equals(this.getUser()) && appointment.getHospital().equals(this.getHospital())
                && appointment.getCause().equals(this.getCause());
    }
}
