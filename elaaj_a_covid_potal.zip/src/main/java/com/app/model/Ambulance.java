package com.app.model;

public class Ambulance {
    private int id;
    private String agency;
    private String phone;
    private Address address;

    public Ambulance() {
        super();
    }

    public Ambulance(int id, String agency, String phone, Address address) {
        this.setId(id);
        this.setAgency(agency);
        this.setPhone(phone);
        this.setAddress(address);
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAgency() {
        return agency;
    }

    public void setAgency(String agency) {
        this.agency = agency;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "id : "+this.getId()+" , agency: "+this.getAgency()+" , phone : "+this.getPhone();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (super.getClass() != obj.getClass())
            return false;
        Ambulance ambulance = (Ambulance) obj;
        boolean isIdSame = ambulance.getId() == this.getId();
        boolean isAgencySame = ambulance.getAgency().equals(this.getAgency());
        boolean isAddressSame = ambulance.getAddress().equals(this.getAddress());
        return isIdSame || (isAgencySame && isAddressSame);
    }
}
