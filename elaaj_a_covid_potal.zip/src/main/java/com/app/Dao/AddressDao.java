package com.app.Dao;

import com.app.model.Address;

public interface AddressDao {

    /**
     * this function used to add address in database
     * @param address
     * @return true if added or false if not
     */
    public boolean addAddress(Address address);

    /**
     * it deletes a row of address table which has this pincode
     * @param pincode
     * @return true if deleted or false if not
     */
    public boolean removeAddress(int pincode);

    /**
     * it takes a address object and update the row which has same picode.
     * pincode cant be changed.
     * @param address
     * @return true if updated or flase if not
     */
    public boolean updateAddress(Address address);

    /**
     * it fetch a row from address table which has this pincode.
     * @param pincode
     * @return address object or null if not found in database
     */
    public Address getAddress(int pincode);
}
