package com.app.Dao;

import java.util.List;

import com.app.model.Supplier;

public interface SupplierDao {

    /**
     * this method will add supplier details in supplier table. for address field
     * use toString() method of address object.
     * 
     * @param supplier
     * @return true if added or false if not
     */
    public boolean addSupplier(Supplier supplier);

    /**
     * delete a supplier details from table. this function use pincode and name of
     * supplier object to select a row in table.
     * 
     * @param supplier
     * @return true if deleted or false if not
     */
    public boolean removeSupplier(Supplier supplier);

    /**
     * this function fetch only one supplier details from table using id.
     * 
     * @param id
     * @return supplier object or null if not found
     */
    public Supplier getSupplier(int id);

    /**
     * this fetch all suppliers details who has this pincode in the table.
     * 
     * @param pincode
     * @return listof suppliers or null
     */
    public List<Supplier> getSuppliers(int pincode);

    /**
     * this function used to update suppliers details. id and pincode cant be
     * changed
     * 
     * @param supplier
     * @return true if updated or false if not
     */
    public boolean updateSupplier(Supplier supplier);
}
