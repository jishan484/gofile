package com.app.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.app.model.Address;
import com.app.model.User;
import com.app.util.DbUtil;

public class UserDaoImpl implements UserDao {

    @Override
    public boolean addNewUser(User user) throws ClassNotFoundException, SQLException {
        Connection con = DbUtil.getConnection(); // getting connection object
        try {
            String query = "SELECT * FROM Users where User_name=?";
            PreparedStatement stmt = con.prepareStatement(query);
            String name = user.getUserName();
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return false;
            } else {
                String insertQuery = "INSERT INTO Users VALUES (?,?,?,?,?,?,?)";
                PreparedStatement insertStmt = con.prepareStatement(insertQuery);
                insertStmt.setInt(1, user.getUserId());
                insertStmt.setString(2, user.getUserName());
                insertStmt.setString(3, user.getPassword());
                insertStmt.setString(4, user.getPhone());
                insertStmt.setString(5, user.getAddress().toString());
                insertStmt.setString(6, user.getType());
                insertStmt.setInt(7, user.getStatus());
                insertStmt.executeUpdate();
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return true;
    }

    @Override
    public boolean removeUser(String userName) throws ClassNotFoundException, SQLException {
        Connection con = DbUtil.getConnection(); // getting connection object
        try {
            String query = "DELETE FROM Users WHERE User_name=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, userName);
            int rowsEffected = stmt.executeUpdate();
            if (rowsEffected == 1) {
                return true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean updateUser(int userId, User user) throws ClassNotFoundException, SQLException {
        Connection con = DbUtil.getConnection(); // getting connection object
        try {
            String query = "UPDATE Users SET User_name=?, Password=?, type=?, address=?, phone=?, status=? WHERE User_id=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, user.getUserName());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getType());
            stmt.setString(4, user.getAddress().toString());
            stmt.setString(5, user.getPhone());
            stmt.setInt(6, user.getStatus());
            stmt.setInt(7, userId);

            int rowAffected = stmt.executeUpdate();

            if (rowAffected == 1) {
                return true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return false;
    }

    @Override
    public User getUserById(int userId) throws ClassNotFoundException, SQLException {
        Connection con = DbUtil.getConnection(); // getting connection object
        try {
            String query = "SELECT * FROM Users where User_id=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String userName = rs.getString("User_name");
                String password = rs.getString("Password");
                String phone = rs.getString("phone");
                String address = rs.getString("address");
                String type = rs.getString("type");
                int status = rs.getInt("status");

                String[] addressArray = address.split(" ");
                int pCode = Integer.parseInt(addressArray[3]);
                Address addressObj = new Address(pCode, addressArray[0], addressArray[1], addressArray[2]);

                User user = new User(userId, userName, password, type, addressObj, phone, status);
                return user;

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return null;
    }

    @Override
    public User getUserByUserName(String userName) throws ClassNotFoundException, SQLException {
        Connection con = DbUtil.getConnection(); // getting connection object
        try {
            String query = "SELECT * FROM Users where User_name=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, userName);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("User_id");
                String password = rs.getString("Password");
                String phone = rs.getString("phone");
                String address = rs.getString("address");
                String type = rs.getString("type");
                int status = rs.getInt("status");

                String[] addressArray = address.split(" ");
                int pCode = Integer.parseInt(addressArray[3]);
                Address addressObj = new Address(pCode, addressArray[0], addressArray[1], addressArray[2]);

                User user = new User(id, userName, password, type, addressObj, phone, status);
                return user;

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return null;
    }

    @Override
    public boolean checkUser(String userName, String password) throws ClassNotFoundException, SQLException {
        Connection con = DbUtil.getConnection(); // getting connection object
        try {
            String query = "SELECT * FROM Users where User_name=? and Password=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, userName);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                if (rs.getString("User_name").equals(userName) && rs.getString("Password").equals(password)) {
                    return true;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

}