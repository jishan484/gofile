package com.app.Dao;

import java.sql.SQLException;

import com.app.model.User;

public interface UserDao {

    /**
     * Insert new user data to database if not already exist in the table.check
     * userName is present in the table or not. if not present then insert new user.
     * 
     * @param user
     * @return true if inserted or false if not
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public boolean addNewUser(User user) throws ClassNotFoundException, SQLException;

    /**
     * Delete user data from table if already exist in the table.
     * 
     * @param userName
     * @return true if deleted or false
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public boolean removeUser(String userName) throws ClassNotFoundException, SQLException;

    /**
     * Update user details in databse.Get user by using getUserById or
     * getUserByUserName and update information of that.Then call this function and
     * pass updated user object.You cannot use this method to update the id field.
     * 
     * @param userId
     * @param user
     * @return true if updated or false if not
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public boolean updateUser(int userId, User user) throws ClassNotFoundException, SQLException;
    /**
     * Retrieves data from database of a specific user_id. create a User object with
     * the data from database and return it.This function can return only one User
     * data.
     * 
     * @param userId
     * @return User if exist in databse or null if not
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public User getUserById(int userId) throws ClassNotFoundException, SQLException;

    /**
     * Retrieves data from database of a specific user_name. create a User object
     * with the data from database and return it.This function can return only one
     * User data.
     * 
     * @param userName
     * @return User if exist in databse or null if not
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public User getUserByUserName(String userName) throws ClassNotFoundException, SQLException;

    /**
     * Check if password is correct for that userName. Search in database if a user
     * present with that username and password.
     * 
     * @param userName
     * @param password
     * @return true if exist or false if not
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public boolean checkUser(String userName, String password) throws ClassNotFoundException, SQLException;
}