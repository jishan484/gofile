package com.app.Dao;

import java.util.List;

import com.app.model.Address;
import com.app.model.Ambulance;

public interface AmbulanceDao {

    /**
     * This inserts new ambulance data into database if same details not exist.
     * Before inserting it checks if same agency name with same pinCode preset in database or
     * not.if not then insert.
     * 
     * @param ambulance
     * @return true if inserted or false if not
     */
    public boolean addAmbulance(Ambulance ambulance);

    /**
     * delete ambulance details from database.
     * 
     * @param ambulance
     * @return true if deleted or false if not
     */
    public boolean removeAmbulance(Ambulance ambulance);

    /**
     * Update ambulance details in databse. it can not be used to update id.
     * use id to update details of a row in database.
     * 
     * @param ambulance
     * @return true if updated or false if not
     */
    public boolean updateAmbulance(Ambulance ambulance);

    /**
     * This returns details of ambulance from database.
     * 
     * @param agency
     * @param pinCode
     * @return Ambulance object if exist or false if not
     */
    public Ambulance getAmbulanceDetails(String agency , int pinCode);

    public List<Ambulance> getAmbulanceList(Address address);

    public List<Ambulance> getAmbulanceList(String pinCode);
}
