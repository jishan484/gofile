package com.app.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbUtil {
    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        Connection con = null;
        Properties props = new Properties();
        try {
            FileInputStream fis = null;
            fis = new FileInputStream("src/reources/connection.properties");
            props.load(fis);
            Class.forName(props.getProperty("DB_DRIVER_CLASS"));
            con = DriverManager.getConnection(props.getProperty("DB_URL"), props.getProperty("DB_USERNAME"),
                    props.getProperty("DB_PASSWORD"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return con;
    }
}
