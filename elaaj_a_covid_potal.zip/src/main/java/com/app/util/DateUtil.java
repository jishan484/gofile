package com.app.util;

import java.util.Date;
import java.text.SimpleDateFormat;

public class DateUtil {
    /**
     * This static function converts date in String format to java.util.Date
     * 
     * @param dateString
     * @return Date
     */
    public static Date convertToDate(String dateString) {
        SimpleDateFormat sDFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date Converted_date = null;
        try {
            Converted_date = sDFormat.parse(dateString);
        } catch (Exception e) {
            System.out.println("wrong format!");
        }
        return Converted_date;
    }

    /**
     * overriden. this function takes extra param for format
     * 
     * @param date
     * @param format
     * @return
     */
    public static Date convertToDate(String date, String format) {
        SimpleDateFormat sDFormat = new SimpleDateFormat(format);
        Date Converted_date = null;
        try {
            Converted_date = sDFormat.parse(date);
        } catch (Exception e) {
            System.out.println("wrong format!");
            e.printStackTrace();
        }
        return Converted_date;
    }

    /**
     * 
     * @return current Date
     */
    public static Date getCurrentDate() {
        return new Date();
    }
}
