<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
         pageEncoding="ISO-8859-1" %>
<%@ taglib prefix="sf" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="s" uri="http://www.springframework.org/tags" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<style>
	.header{font-weight:1000; color:#3f51b5;font-size:70px;}
	h1{ color: #e91e63; font-weight:700;}
	#mask{ font-size: 70px;}
</style>
<body style="background-color: lavender">
<br><br><br>
	<center>
		<div class="header">UNDER<br>CONSTRUCTION</div>
		<h1 class="time"></h1>
		<h1 id="mask">&#128567;</h1>
	</center>
	<script>
		setInterval(() => {
			var now = new Date();
			var then = new Date("2021-06-05");
			var diffrence = toString(then.getTime() - now.getTime());
			document.querySelector(".time").innerHTML = diffrence;
		}, 1000);
		function toString(a){
			var seconds = a / 1000;
			var minutes = seconds / 60;
			var hours = minutes / 60;
			var days = hours / 24;
			return Math.round(days) + " Days " + Math.round(hours % 24) + " Hours " + Math.round(minutes % 60) + " Minutes " + Math.round(seconds % 60) +" Seconds"; 
		}
	</script>
</body>
</html>